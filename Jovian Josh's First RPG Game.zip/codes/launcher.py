import subprocess
import sys

subprocess.run([sys.executable, "battle.py"])
